package jardinbotanico;

public class PlantaRepetidaException extends RuntimeException{
    
    public final static String MESSAGE = "La planta que intentas agregar esta repetida.";
    
    public PlantaRepetidaException() {
        super(MESSAGE);
    } 
}
