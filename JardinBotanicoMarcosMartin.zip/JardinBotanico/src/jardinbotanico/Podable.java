package jardinbotanico;

public interface Podable {
    
    void podar();
    
}
