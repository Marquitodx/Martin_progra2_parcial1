package jardinbotanico;

public class Flor extends Planta{
    
    private TemporadaFlorecimiento temporada;
    
    public Flor(String nombre, String ubicacion, String clima, TemporadaFlorecimiento temporada) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }
    
    @Override
    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if(o == null || o.getClass() != getClass()){
            return false;
        }
        Flor other = (Flor) o;
        return nombre.equals(other.nombre) && ubicacion.equals(other.ubicacion);
    }

    
    @Override
    public String toString() {
        return "Flor | " + "nombre: " + nombre + " - ubicacion: " + ubicacion + " - clima: " + clima + " - temporada: " + temporada;
    }

    
    @Override
    public boolean puedePodarse() {
        return false;
    }
    
    
    
}
