package jardinbotanico;

public class Arbol extends Planta implements Podable{
    
    private final int alturaMaxima;
    
    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }
    
    @Override
    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if(o == null || o.getClass() != getClass()){
            return false;
        }
        Arbol other = (Arbol) o;
        return nombre.equals(other.nombre) && ubicacion.equals(other.ubicacion);
    }
    
    
    @Override
    public String toString() {
        return "Arbol | " + "nombre: " + nombre + " - ubicacion: " + ubicacion +
                " - clima: " + clima + " - altura maxima: " + alturaMaxima;
    }
    
    
    @Override
    public void podar() {
        System.out.println("El arbol ha sido podado!");
    }

    
    @Override
    public boolean puedePodarse() {
        return true;
    }
    
    
    
}
