package jardinbotanico;

import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {
    
    private String nombre;
    private List<Planta> plantas;
    
    
    public JardinBotanico(String nombre){
        this.nombre = nombre;
        this.plantas = new ArrayList<>();
    }

    
// metodo para comprobar si esta repetida la planta
    private boolean estaRepetido(Planta planta){
        for(Planta p: plantas){
            if(planta.equals(p)){
                return true;
            }
        }return false;
    }    
    
    
    public void agregarPlanta(Planta planta){
        if(planta != null){
            if(!estaRepetido(planta)){
                plantas.add(planta);
            }else{
                throw new PlantaRepetidaException();
            }            
        }else{
            throw new NullPointerException("Loco, me pasaste un NULL en lugar de una planta!");
        }
    }
    
    
    public void mostrarPlantas(){
        if(plantas.isEmpty()){
            System.out.println("La lista de plantas esta vacia.");
        }
        for(Planta p: plantas){
                System.out.println(p.toString());
            }
    }

    
    public void podarPlantas(){
        for(Planta p: plantas){
            if(p.puedePodarse()){
                System.out.println("Estamos podando el " + p.getNombre());
            }
            else{
                System.out.println("Las flores no pueden podarse.");
            }
        }
    }
    
    
}
