package jardinbotanico;

public class testJardinBotanico {

    public static void main(String[] args) {
        
        JardinBotanico botanico = new JardinBotanico("Jardin botanico Buenos Aires");
        
        try{
            botanico.agregarPlanta(new Arbusto("Jazmin", "Sur", "humedo", 8));
            botanico.agregarPlanta(new Flor("Jazmin", "Sur", "humedo", TemporadaFlorecimiento.PRIMAVERA));
            botanico.agregarPlanta(new Arbol("Roble", "Norte", "seco", 12));
            botanico.agregarPlanta(new Arbol("Alamo", "Norte", "humedo", 10));
            botanico.agregarPlanta(new Arbol("Alerce", "Norte", "seco", 10));
        } 
        catch (RuntimeException e) {
            System.out.println(e.getMessage());    
        }
        
        
        botanico.mostrarPlantas();
        
    }
    
}
