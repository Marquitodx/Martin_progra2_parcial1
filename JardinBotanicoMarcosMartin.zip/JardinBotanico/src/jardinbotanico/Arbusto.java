package jardinbotanico;

public class Arbusto extends Planta implements Podable{
    
    public static final int MIN_VALUE = 1;
    public static final int MAX_VALUE = 10;
    
    private final int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidad) {
        super(nombre, ubicacion, clima);
        validarDensidad(densidad);
        densidadFollaje = densidad;
    }
    
    
    private void validarDensidad(int densidad){
        if(densidad < MIN_VALUE || densidad > MAX_VALUE){
            throw new IllegalArgumentException("Error. La densidad debe ser entre 1 y 10.");
        }
    }    
    
    
    @Override
    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if(o == null || o.getClass() != getClass()){
            return false;
        }
        Arbusto other = (Arbusto) o;
        return nombre.equals(other.nombre) && ubicacion.equals(other.ubicacion);
    }
    
    
    @Override
    public void podar() {
        System.out.println("El arbusto ha sido podado!");
    }
    
    
    @Override
    public String toString() {
        return "Arbusto | " + "nombre: " + nombre + " - ubicacion: " + ubicacion +
                " - clima: " + clima + " - densidad de follaje: " + densidadFollaje;
    }

    
    @Override
    public boolean puedePodarse() {
        return true;
    }
    
    
    
}
